
Config = {}

Config.LootItems = {
    { name = "pistol_ammo", min = 5, max = 15 },
    { name = "water", min = 1, max = 3 }
}

Config.notifyTime = 5000
return Config
