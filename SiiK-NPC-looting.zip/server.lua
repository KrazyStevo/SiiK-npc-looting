
local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('npcLoot:getLoot')
AddEventHandler('npcLoot:getLoot', function()
    local src = source
    local lootTable = Config.LootItems

    local loot = lootTable[math.random(#lootTable)]
    local quantity = math.random(loot.min, loot.max)

    TriggerClientEvent('npcLoot:receiveLoot', src, loot.name, quantity)
end)

RegisterNetEvent('npcLoot:addToInventory')
AddEventHandler('npcLoot:addToInventory', function(item, quantity)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        if item == "ammo_pistol" then
            TriggerClientEvent("weapons:client:AddAmmo", src, "AMMO_PISTOL", quantity)
            TriggerClientEvent('QBCore:Notify', src, "You looted "..quantity.." pistol ammo!", "success")
        else
            Player.Functions.AddItem(item, quantity)
            TriggerClientEvent('QBCore:Notify', src, "You looted "..quantity.."x "..item, "success")
        end
    end
end)

RegisterServerEvent('dispatch:notifyPolice')
AddEventHandler('dispatch:notifyPolice', function(coords)
    TriggerClientEvent('npcLoot:getStreetName', -1, coords)
end)

RegisterNetEvent('npcLoot:returnStreetName')
AddEventHandler('npcLoot:returnStreetName', function(streetName, coords)
    local dispatchMessage = "Looting in progress at " .. streetName

    TriggerEvent('qs-dispatch:server:CreateCall', {
        job = { 'police' },
        callLocation = streetName,
        coords = coords,
        title = '10-90 | Looting Alert',
        message = dispatchMessage,
        blip = {
            sprite = 161,
            color = 1,
            scale = 1.2
        },
        duration = 60,
        anonymous = false
    })

    TriggerClientEvent('QBCore:Notify', -1, "Police have been alerted about looting at: " .. streetName, "error")
end)
