
fx_version 'cerulean'
game 'gta5'

description 'NPC Looting with Custom Skillbar, NUI Progress Bar, and Animation'
author 'ChatGPT'
version '1.3.0'

client_scripts {
    'client.lua',
    'progressbar/client.lua'
}

server_scripts {
    '@qb-core/shared/locale.lua',
    'config.lua',
    'server.lua'
}

files {
    'progressbar/h.html'
}

ui_page 'progressbar/h.html'

dependencies {
    'qb-core',
    'qb-skillbar'
}
