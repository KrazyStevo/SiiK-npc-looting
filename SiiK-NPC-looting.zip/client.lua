
local lootCooldown = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)

        local targetPed = GetClosestDeadNPC(coords)

        if targetPed ~= 0 and IsEntityDead(targetPed) and not IsPedAPlayer(targetPed) and not lootCooldown then
            local targetCoords = GetEntityCoords(targetPed)
            local dist = #(coords - targetCoords)

            if dist < 2.0 then
                DrawText3D(targetCoords.x, targetCoords.y, targetCoords.z + 0.5, '[E] Loot Body')

                if IsControlJustPressed(0, 51) then
                    local Skillbar = exports['qb-skillbar']:GetSkillbarObject()
                    Skillbar.Start({
                        duration = math.random(4000,6000),
                        pos = math.random(10, 30),
                        width = math.random(10, 20)
                    },
                    function() -- Success
                        RequestAnimDict("amb@prop_human_bum_bin@base")
                        while not HasAnimDictLoaded("amb@prop_human_bum_bin@base") do
                            Citizen.Wait(10)
                        end
                        TaskPlayAnim(playerPed, "amb@prop_human_bum_bin@base", "base", 8.0, -8, -1, 1, 0, false, false, false)

                        startUI(30000, "Looting Body...")
                        Citizen.Wait(30000)

                        ClearPedTasks(playerPed)

                        TriggerServerEvent('npcLoot:getLoot')
                        TriggerServerEvent('dispatch:notifyPolice', targetCoords)
                        DeleteEntity(targetPed)

                        local nearbyPeds = GetNearbyPeds(coords.x, coords.y, coords.z, 10.0)
                        for _, ped in ipairs(nearbyPeds) do
                            if DoesEntityExist(ped) and not IsEntityDead(ped) and not IsPedAPlayer(ped) then
                                TaskCombatPed(ped, playerPed, 0, 16)
                            end
                        end

                        lootCooldown = true
                        Citizen.SetTimeout(180000, function()
                            lootCooldown = false
                        end)
                    end, 
                    function() -- Fail
                        TriggerEvent('QBCore:Notify', "You failed to start looting!", "error")
                    end)
                end
            end
        end
    end
end)

-- Helper functions stay the same
function DrawText3D(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local scale = 0.35
    if onScreen then
        SetTextScale(scale, scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    end
end

function GetNearbyPeds(x, y, z, radius)
    local nearbyPeds = {}
    for ped in EnumeratePeds() do
        local pedCoords = GetEntityCoords(ped)
        local distance = #(vector3(x, y, z) - pedCoords)
        if distance <= radius then
            table.insert(nearbyPeds, ped)
        end
    end
    return nearbyPeds
end

function EnumeratePeds()
    return coroutine.wrap(function()
        local handle, ped = FindFirstPed()
        local success
        repeat
            coroutine.yield(ped)
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end)
end

function GetClosestDeadNPC(coords)
    local closestPed = nil
    local closestDist = 2.0
    for ped in EnumeratePeds() do
        if IsEntityDead(ped) and not IsPedAPlayer(ped) then
            local pedCoords = GetEntityCoords(ped)
            local dist = #(coords - pedCoords)
            if dist < closestDist then
                closestDist = dist
                closestPed = ped
            end
        end
    end
    return closestPed or 0
end

RegisterNetEvent('npcLoot:getStreetName')
AddEventHandler('npcLoot:getStreetName', function(coords)
    local streetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    TriggerServerEvent('npcLoot:returnStreetName', streetName, coords)
end)
