
# NPC Loot System

A FiveM script that allows players to loot dead NPCs with an interactive experience.

## 🚨 Features
- **Custom Skillbar Minigame** before looting.
- **Searching Animation** during looting.
- **Custom NUI Progress Bar** (30 seconds) to simulate searching.
- Automatic **Police Dispatch Alert** using `qs-dispatch` (if installed).
- Cooldown system to prevent spam looting.

## 📦 Installation
1. Clone or download this repository into your `resources` folder.
2. Ensure you have the following dependencies installed and running:
   - [`qb-core`](https://github.com/qbcore-framework/qb-core)
   - A custom [`qb-skillbar`](your-skillbar-link) (the one you provided, renamed as `qb-skillbar`).
3. Add the following to your `server.cfg`:

```
ensure qb-core
ensure qb-skillbar
ensure npc-loot-system
```

## ⚙️ Configuration
Edit `config.lua` to adjust loot items and notification settings.

## 🎮 Usage
Approach a dead NPC and press **[E]** to start looting. 
- Complete the skillbar minigame.
- Wait for the progress bar to finish.
- Receive loot and trigger a police alert.

## 📄 License
This project is licensed under the MIT License.
