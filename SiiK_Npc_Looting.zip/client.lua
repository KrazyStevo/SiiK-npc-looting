local lootCooldown = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)

        local targetPed = GetClosestDeadNPC(coords)

        if targetPed ~= 0 and IsEntityDead(targetPed) and not IsPedAPlayer(targetPed) and not lootCooldown then
            local targetCoords = GetEntityCoords(targetPed)
            local dist = #(coords - targetCoords)

            if dist < 2.0 then
                DrawText3D(targetCoords.x, targetCoords.y, targetCoords.z + 0.5, '[E] Loot Body')

                if IsControlJustPressed(0, 51) then
                    -- Loot NPC without progress bar or minigame
                    TriggerServerEvent('npcLoot:getLoot')
                    TriggerServerEvent('dispatch:notifyPolice', targetCoords)
                    DeleteEntity(targetPed)

                    local nearbyPeds = GetNearbyPeds(coords.x, coords.y, coords.z, 10.0)
                    for _, ped in ipairs(nearbyPeds) do
                        if DoesEntityExist(ped) and not IsEntityDead(ped) and not IsPedAPlayer(ped) then
                            TaskCombatPed(ped, playerPed, 0, 16)
                        end
                    end

                    lootCooldown = true
                    Citizen.SetTimeout(180000, function()
                        lootCooldown = false
                    end)
                end
            end
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    local scale = 0.35
   
    if onScreen then
        SetTextScale(scale, scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    end
end

function GetNearbyPeds(x, y, z, radius)
    local nearbyPeds = {}
    for ped in EnumeratePeds() do
        local pedCoords = GetEntityCoords(ped)
        local distance = #(vector3(x, y, z) - pedCoords)
        if distance <= radius then
            table.insert(nearbyPeds, ped)
        end
    end
    return nearbyPeds
end

function EnumeratePeds()
    return coroutine.wrap(function()
        local handle, ped = FindFirstPed()
        local success
        repeat
            coroutine.yield(ped)
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end)
end

function GetClosestDeadNPC(coords)
    local closestPed = nil
    local closestDist = 2.0
    for ped in EnumeratePeds() do
        if IsEntityDead(ped) and not IsPedAPlayer(ped) then
            local pedCoords = GetEntityCoords(ped)
            local dist = #(coords - pedCoords)
            if dist < closestDist then
                closestDist = dist
                closestPed = ped
            end
        end
    end
    return closestPed
end

RegisterNetEvent('npcLoot:receiveLoot')
AddEventHandler('npcLoot:receiveLoot', function(item, quantity)
    TriggerServerEvent('npcLoot:addToInventory', item, quantity)
end)