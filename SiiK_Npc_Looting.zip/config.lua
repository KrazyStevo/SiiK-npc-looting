Config = {}

Config.LootItems = {
    { name = "pistol_ammo", min = 5, max = 15 },
    { name = "bread", min = 1, max = 3 }
}

Config.notifyTime = 5000 -- Time in ms for police notification after looting

return Config