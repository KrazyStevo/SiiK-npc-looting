local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('npcLoot:getLoot')
AddEventHandler('npcLoot:getLoot', function()
    local src = source
    local lootTable = Config.LootItems

    local loot = lootTable[math.random(#lootTable)]
    local quantity = math.random(loot.min, loot.max)

    TriggerClientEvent('npcLoot:receiveLoot', src, loot.name, quantity)
end)

RegisterNetEvent('npcLoot:addToInventory')
AddEventHandler('npcLoot:addToInventory', function(item, quantity)
    print("[DEBUG] Adding to inventory: "..item.." x"..quantity)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        if item == "pistol_ammo" then
            TriggerClientEvent("weapons:client:AddAmmo", src, "AMMO_PISTOL", quantity)
            TriggerClientEvent('QBCore:Notify', src, "You looted "..quantity.." pistol ammo!", "success")
        else
            Player.Functions.AddItem(item, quantity)
            TriggerClientEvent('QBCore:Notify', src, "You looted "..quantity.."x "..item, "success")
        end
    end
end)

RegisterServerEvent('dispatch:notifyPolice')
AddEventHandler('dispatch:notifyPolice', function(coords)
    print("[DEBUG] Police notification triggered at coordinates: " .. tostring(coords))  -- Debug print
    local dispatchMessage = "Looting in progress at location: " .. "X: " .. coords.x .. " Y: " .. coords.y .. " Z: " .. coords.z
    print("[DEBUG] Dispatch Message: " .. dispatchMessage) -- Debug log for dispatch message

    -- Trigger the qb-dispatch event for police alert and mark location on the map
    TriggerEvent('qb-dispatch:addPoliceAlert', {
        coords = vector3(coords.x, coords.y, coords.z),
        message = dispatchMessage,
        alertType = "robbery",  -- Customizable alert type
        priority = 1,
        blip = {
            sprite = 434,  -- Police blip icon
            color = 38,    -- Blip color (blue)
            scale = 1.0    -- Size of the blip on the map
        }
    })
    
    -- Trigger QBCore Notify as fallback for in-game notification
    TriggerClientEvent('QBCore:Notify', -1, "Police have been alerted about looting at: " .. dispatchMessage, "error")
end)